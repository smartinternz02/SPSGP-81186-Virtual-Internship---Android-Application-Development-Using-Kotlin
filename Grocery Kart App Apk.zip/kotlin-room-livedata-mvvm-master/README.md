# kotlin-room-livedata-mvvm
![mqdefault](https://user-images.githubusercontent.com/107117774/174491146-4b7042e1-a1a9-4304-9256-71464f04b04e.jpg)
